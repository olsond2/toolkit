#!/bin/sh
set -ex
git clone https://github.com/OISF/libhtp -b 0.5.x
