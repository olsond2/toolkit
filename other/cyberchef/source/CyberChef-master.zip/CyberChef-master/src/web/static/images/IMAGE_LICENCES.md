## Image attribution

The following image files in this directory are taken from open sources:

| File                  | Licence                                   | Attribution                                                                   |
| --------------------- | ----------------------------------------- | ----------------------------------------------------------------------------- |
| cook_female-32x32.png | Creative Commons Attribution 3.0 Unported | https://commons.wikimedia.org/wiki/File:Farm-Fresh_user_cook_female_white.png |
| cook_male-32x32.png   | Creative Commons Attribution 3.0 Unported | https://commons.wikimedia.org/wiki/File:Farm-Fresh_user_cook_male_white.png   |
| file-32x32.png        | Free for commercial use                   | https://www.iconfinder.com/icons/66768/file_info_icon                         |
| file-128x128.png      | Free for commercial use                   | https://www.iconfinder.com/icons/66768/file_info_icon                         |
